// GET NEXT VARIANT — the outer-loop cursor.
// Finds the next TODAY digest variant whose sendStatus is not 'complete'.
// Returns that single variant row (with its sheet row number for status updates),
// or signals done when none remain.
//
// Input: $('Fetch Today's Digests').all() → today's digest rows incl. sendStatus
//        (Google Sheets read returns row_number when "include row number" is on,
//         or use the node's built-in row tracking)
// Output: { _done: true } if nothing left, else the next variant row to process.

const rows = $("Fetch Today's Digests").all().map(i => i.json);
const TODAY = new Date().toISOString().slice(0, 10);

// Skip ONLY completed variants. A 'sending' variant may still have undrained
// subscribers (chunked sends across ticks), so it must remain pickable. The
// per-subscriber lastSentDate filter in send-batch prevents any double-send.
const isClaimed = (v) => String(v || '').trim().toLowerCase() === 'complete';

// Only today's variants (match by timestamp date), newest per type
const todays = rows.filter(r => {
  const ts = (r.timestamp || '').slice(0, 10);
  return ts === TODAY && r.html && r.subject;
});

// Dedup to newest per partnerType
const byType = {};
for (const r of todays) {
  const t = (r.partnerType || 'general').trim().toLowerCase();
  if (!byType[t] || new Date(r.timestamp||0) > new Date(byType[t].timestamp||0)) byType[t] = r;
}

// First incomplete variant
const next = Object.values(byType).find(r => !isClaimed(r.sendStatus));

if (!next) {
  return [{ json: { _done: true } }];
}

return [{ json: { ...next } }];
